"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Leaf, ArrowLeft, CreditCard, Shield, Lock, Check } from "lucide-react"
import Link from "next/link"

export default function CheckoutPage() {
  const [isProcessing, setIsProcessing] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState("card")
  const [isYearly] = useState(false) // This would come from the subscription page

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)

    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false)
      // Redirect to success page or dashboard
      window.location.href = "/billing?success=true"
    }, 3000)
  }

  const price = isYearly ? 95.9 : 9.99
  const period = isYearly ? "Jahr" : "Monat"

  return (
    <div className="min-h-screen bg-background">
      {/* Background Animation */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-green-50/30 via-background to-green-50/20" />
        <div className="absolute top-10 left-10 animate-bounce delay-1000">
          <Leaf className="w-8 h-8 text-green-200 rotate-12" />
        </div>
        <div className="absolute bottom-20 right-20 animate-pulse delay-2000">
          <Leaf className="w-6 h-6 text-green-300 -rotate-45" />
        </div>
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-border bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/subscription" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">GrowAI</span>
          </Link>
          <Badge className="bg-primary/10 text-primary border-primary/20">
            <Shield className="w-3 h-3 mr-1" />
            SSL-verschlüsselt
          </Badge>
        </div>
      </header>

      <div className="relative z-10 py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          {/* Header */}
          <div className="mb-8">
            <Link
              href="/subscription"
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-4"
            >
              <ArrowLeft className="w-4 h-4" />
              Zurück zur Preisübersicht
            </Link>
            <h1 className="text-3xl font-bold text-foreground mb-2">Checkout</h1>
            <p className="text-muted-foreground">Schließen Sie Ihr GrowAI Pro Abonnement ab</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Payment Form */}
            <div className="lg:col-span-2">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Payment Method */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CreditCard className="w-5 h-5 text-primary" />
                      Zahlungsmethode
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-3">
                      <Button
                        type="button"
                        variant={paymentMethod === "card" ? "default" : "outline"}
                        onClick={() => setPaymentMethod("card")}
                        className="h-12"
                      >
                        Kreditkarte
                      </Button>
                      <Button
                        type="button"
                        variant={paymentMethod === "paypal" ? "default" : "outline"}
                        onClick={() => setPaymentMethod("paypal")}
                        className="h-12"
                      >
                        PayPal
                      </Button>
                      <Button
                        type="button"
                        variant={paymentMethod === "sepa" ? "default" : "outline"}
                        onClick={() => setPaymentMethod("sepa")}
                        className="h-12"
                      >
                        SEPA
                      </Button>
                    </div>

                    {paymentMethod === "card" && (
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="cardNumber">Kartennummer</Label>
                          <Input id="cardNumber" placeholder="1234 5678 9012 3456" required />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="expiry">Ablaufdatum</Label>
                            <Input id="expiry" placeholder="MM/JJ" required />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="cvc">CVC</Label>
                            <Input id="cvc" placeholder="123" required />
                          </div>
                        </div>
                      </div>
                    )}

                    {paymentMethod === "sepa" && (
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="iban">IBAN</Label>
                          <Input id="iban" placeholder="DE89 3704 0044 0532 0130 00" required />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="accountHolder">Kontoinhaber</Label>
                          <Input id="accountHolder" placeholder="Max Mustermann" required />
                        </div>
                      </div>
                    )}

                    {paymentMethod === "paypal" && (
                      <div className="text-center py-8">
                        <p className="text-muted-foreground mb-4">Sie werden zu PayPal weitergeleitet</p>
                        <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mx-auto">
                          <span className="text-blue-600 font-bold text-xl">PP</span>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Billing Information */}
                <Card>
                  <CardHeader>
                    <CardTitle>Rechnungsinformationen</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">Vorname</Label>
                        <Input id="firstName" placeholder="Max" required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">Nachname</Label>
                        <Input id="lastName" placeholder="Mustermann" required />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">E-Mail-Adresse</Label>
                      <Input id="email" type="email" placeholder="max@beispiel.de" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="address">Adresse</Label>
                      <Input id="address" placeholder="Musterstraße 123" required />
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="zip">PLZ</Label>
                        <Input id="zip" placeholder="12345" required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="city">Stadt</Label>
                        <Input id="city" placeholder="Berlin" required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="country">Land</Label>
                        <Select defaultValue="DE">
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="DE">Deutschland</SelectItem>
                            <SelectItem value="AT">Österreich</SelectItem>
                            <SelectItem value="CH">Schweiz</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Terms */}
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-3">
                      <input type="checkbox" id="terms" className="mt-1" required />
                      <Label htmlFor="terms" className="text-sm leading-relaxed">
                        Ich akzeptiere die{" "}
                        <Link href="#" className="text-primary hover:underline">
                          Allgemeinen Geschäftsbedingungen
                        </Link>{" "}
                        und{" "}
                        <Link href="#" className="text-primary hover:underline">
                          Datenschutzerklärung
                        </Link>
                        . Ich verstehe, dass mein Abonnement automatisch verlängert wird und ich jederzeit kündigen
                        kann.
                      </Label>
                    </div>
                  </CardContent>
                </Card>

                <Button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                  size="lg"
                >
                  {isProcessing ? (
                    <>
                      <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2" />
                      Zahlung wird verarbeitet...
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4 mr-2" />
                      Jetzt bezahlen - €{price.toFixed(2)}
                    </>
                  )}
                </Button>
              </form>
            </div>

            {/* Order Summary */}
            <div>
              <Card className="sticky top-8">
                <CardHeader>
                  <CardTitle>Bestellübersicht</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-foreground">GrowAI Pro</span>
                    <Badge className="bg-primary/10 text-primary border-primary/20">Premium</Badge>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-primary" />
                      <span>Unbegrenzte Pflanzen</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-primary" />
                      <span>Wöchentliche KI-Analyse</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-primary" />
                      <span>24/7 Support</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-primary" />
                      <span>Premium-Features</span>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span>€{price.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>MwSt. (19%)</span>
                      <span>€{(price * 0.19).toFixed(2)}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-semibold text-lg">
                      <span>Gesamt</span>
                      <span>€{(price * 1.19).toFixed(2)}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Wird {isYearly ? "jährlich" : "monatlich"} abgerechnet
                    </p>
                  </div>

                  <div className="bg-muted/50 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <Shield className="w-4 h-4 text-primary" />
                      <span className="text-sm font-medium">30 Tage Geld-zurück-Garantie</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Nicht zufrieden? Wir erstatten Ihnen den vollen Betrag.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
