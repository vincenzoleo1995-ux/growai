"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Leaf, ArrowRight, ArrowLeft, Calendar, Thermometer, Droplets } from "lucide-react"
import Link from "next/link"

const cannabisStrains = [
  { id: "white-widow", name: "White Widow", type: "Hybrid", flowering: "8-9 Wochen" },
  { id: "northern-lights", name: "Northern Lights", type: "Indica", flowering: "7-8 Wochen" },
  { id: "sour-diesel", name: "Sour Diesel", type: "Sativa", flowering: "10-11 Wochen" },
  { id: "og-kush", name: "OG Kush", type: "Hybrid", flowering: "8-9 Wochen" },
  { id: "blue-dream", name: "Blue Dream", type: "Hybrid", flowering: "9-10 Wochen" },
  { id: "amnesia-haze", name: "Amnesia Haze", type: "Sativa", flowering: "10-12 Wochen" },
]

export default function SetupPage() {
  const [step, setStep] = useState(1)
  const [selectedStrain, setSelectedStrain] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1)
    } else {
      setIsLoading(true)
      setTimeout(() => {
        window.location.href = "/dashboard"
      }, 2000)
    }
  }

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1)
    }
  }

  const progress = (step / 3) * 100

  return (
    <div className="min-h-screen bg-background">
      {/* Background Animation */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-green-50/30 via-background to-green-50/20" />
        <div className="absolute top-10 left-10 animate-bounce delay-1000">
          <Leaf className="w-8 h-8 text-green-200 rotate-12" />
        </div>
        <div className="absolute bottom-20 right-20 animate-pulse delay-2000">
          <Leaf className="w-6 h-6 text-green-300 -rotate-45" />
        </div>
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-border bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">GrowAI</span>
          </Link>
          <Badge variant="outline" className="bg-accent/10 text-accent border-accent/20">
            Kostenlose Testversion aktiv
          </Badge>
        </div>
      </header>

      <div className="relative z-10 py-12 px-4">
        <div className="container mx-auto max-w-2xl">
          {/* Progress */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">Schritt {step} von 3</span>
              <span className="text-sm text-muted-foreground">{Math.round(progress)}% abgeschlossen</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          {/* Step 1: Strain Selection */}
          {step === 1 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Leaf className="w-5 h-5 text-primary" />
                  Cannabis-Sorte auswählen
                </CardTitle>
                <CardDescription>
                  Wählen Sie die Sorte aus, die Sie anbauen möchten. Dies hilft unserer KI, spezifische Empfehlungen zu
                  geben.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-3">
                  {cannabisStrains.map((strain) => (
                    <div
                      key={strain.id}
                      className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                        selectedStrain === strain.id
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/50"
                      }`}
                      onClick={() => setSelectedStrain(strain.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium text-foreground">{strain.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {strain.type} • Blütezeit: {strain.flowering}
                          </p>
                        </div>
                        <div className="w-4 h-4 border-2 rounded-full border-primary flex items-center justify-center">
                          {selectedStrain === strain.id && <div className="w-2 h-2 bg-primary rounded-full" />}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="pt-4">
                  <Button onClick={handleNext} disabled={!selectedStrain} className="w-full">
                    Weiter
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 2: Growing Environment */}
          {step === 2 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Thermometer className="w-5 h-5 text-primary" />
                  Anbau-Umgebung
                </CardTitle>
                <CardDescription>
                  Geben Sie Informationen über Ihre Anbau-Umgebung an, damit wir optimale Empfehlungen geben können.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="growType">Anbau-Art</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Wählen Sie..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="indoor">Indoor</SelectItem>
                        <SelectItem value="outdoor">Outdoor</SelectItem>
                        <SelectItem value="greenhouse">Gewächshaus</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="medium">Anbau-Medium</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Wählen Sie..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="soil">Erde</SelectItem>
                        <SelectItem value="hydro">Hydroponik</SelectItem>
                        <SelectItem value="coco">Kokos</SelectItem>
                        <SelectItem value="aero">Aeroponik</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="lightType">Beleuchtung</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Wählen Sie..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="led">LED</SelectItem>
                        <SelectItem value="hps">HPS</SelectItem>
                        <SelectItem value="cfl">CFL</SelectItem>
                        <SelectItem value="natural">Natürliches Licht</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="spaceSize">Anbau-Fläche (m²)</Label>
                    <Input id="spaceSize" type="number" placeholder="z.B. 1.2" step="0.1" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="experience">Erfahrungslevel</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Wählen Sie Ihr Erfahrungslevel..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Anfänger</SelectItem>
                      <SelectItem value="intermediate">Fortgeschritten</SelectItem>
                      <SelectItem value="expert">Experte</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button variant="outline" onClick={handleBack} className="flex-1 bg-transparent">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Zurück
                  </Button>
                  <Button onClick={handleNext} className="flex-1">
                    Weiter
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 3: Plant Details */}
          {step === 3 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-primary" />
                  Pflanzen-Details
                </CardTitle>
                <CardDescription>
                  Geben Sie die aktuellen Details Ihrer Pflanze(n) ein, um mit der KI-Analyse zu beginnen.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="plantCount">Anzahl Pflanzen</Label>
                    <Input id="plantCount" type="number" placeholder="z.B. 4" min="1" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="plantAge">Alter (Tage seit Keimung)</Label>
                    <Input id="plantAge" type="number" placeholder="z.B. 14" min="0" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="currentStage">Aktuelle Wachstumsphase</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Wählen Sie die aktuelle Phase..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="seedling">Keimling</SelectItem>
                      <SelectItem value="vegetative">Vegetative Phase</SelectItem>
                      <SelectItem value="flowering">Blütephase</SelectItem>
                      <SelectItem value="harvest">Ernte-bereit</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Zusätzliche Notizen (optional)</Label>
                  <Textarea id="notes" placeholder="Besondere Beobachtungen, verwendete Nährstoffe, etc..." rows={3} />
                </div>

                <div className="bg-accent/10 border border-accent/20 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <Droplets className="w-5 h-5 text-accent mt-0.5" />
                    <div>
                      <h4 className="font-medium text-foreground mb-1">Nächster Schritt: Erstes Foto</h4>
                      <p className="text-sm text-muted-foreground">
                        Nach der Einrichtung können Sie Ihr erstes Foto hochladen und erhalten sofort KI-basierte
                        Empfehlungen für Ihre Pflanzen.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button variant="outline" onClick={handleBack} className="flex-1 bg-transparent">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Zurück
                  </Button>
                  <Button onClick={handleNext} disabled={isLoading} className="flex-1">
                    {isLoading ? "Wird eingerichtet..." : "Einrichtung abschließen"}
                    {!isLoading && <ArrowRight className="w-4 h-4 ml-2" />}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
