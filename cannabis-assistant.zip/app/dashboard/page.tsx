"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Leaf,
  Camera,
  Calendar,
  Droplets,
  Thermometer,
  Sun,
  TrendingUp,
  Clock,
  AlertCircle,
  Plus,
  BarChart3,
} from "lucide-react"
import Link from "next/link"

export default function DashboardPage() {
  const [trialTimeLeft] = useState(45) // minutes left in trial

  return (
    <div className="min-h-screen bg-background">
      {/* Background Animation */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-green-50/30 via-background to-green-50/20" />
        <div className="absolute top-10 left-10 animate-bounce delay-1000">
          <Leaf className="w-8 h-8 text-green-200 rotate-12" />
        </div>
        <div className="absolute bottom-20 right-20 animate-pulse delay-2000">
          <Leaf className="w-6 h-6 text-green-300 -rotate-45" />
        </div>
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-border bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">GrowAI</span>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="bg-accent/10 text-accent border-accent/20">
              <Clock className="w-3 h-3 mr-1" />
              {trialTimeLeft} Min. Testversion
            </Badge>
            <Avatar>
              <AvatarFallback>MU</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      <div className="relative z-10 py-8 px-4">
        <div className="container mx-auto max-w-6xl">
          {/* Welcome Section */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Willkommen zurück, Max!</h1>
            <p className="text-muted-foreground">Hier ist der aktuelle Status Ihrer Cannabis-Pflanzen</p>
          </div>

          {/* Trial Banner */}
          <Card className="mb-8 border-accent/20 bg-accent/5">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center">
                    <Clock className="w-5 h-5 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Kostenlose Testversion aktiv</h3>
                    <p className="text-sm text-muted-foreground">
                      Noch {trialTimeLeft} Minuten verbleibend. Upgraden Sie für unbegrenzten Zugang.
                    </p>
                  </div>
                </div>
                <Button className="bg-primary hover:bg-primary/90">Jetzt upgraden - €9,99/Monat</Button>
              </div>
            </CardContent>
          </Card>

          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Aktive Pflanzen</p>
                    <p className="text-2xl font-bold text-foreground">4</p>
                  </div>
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Leaf className="w-5 h-5 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Tage seit Keimung</p>
                    <p className="text-2xl font-bold text-foreground">21</p>
                  </div>
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Gesundheitsscore</p>
                    <p className="text-2xl font-bold text-primary">92%</p>
                  </div>
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Nächste Bewässerung</p>
                    <p className="text-2xl font-bold text-foreground">2h</p>
                  </div>
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Droplets className="w-5 h-5 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Plant Card */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>White Widow #1</CardTitle>
                      <CardDescription>Vegetative Phase • Tag 21</CardDescription>
                    </div>
                    <Badge className="bg-orange-100 text-orange-600 border-orange-200">Aufmerksamkeit nötig</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Plant Image Placeholder */}
                  <div className="aspect-video bg-muted rounded-lg flex items-center justify-center border-2 border-dashed border-border">
                    <div className="text-center">
                      <Camera className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground mb-2">Letztes Foto vor 3 Tagen</p>
                      <Link href="/upload">
                        <Button size="sm" className="bg-primary hover:bg-primary/90">
                          <Camera className="w-4 h-4 mr-2" />
                          Neues Foto hochladen
                        </Button>
                      </Link>
                    </div>
                  </div>

                  {/* Growth Progress */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-foreground">Wachstumsfortschritt</span>
                      <span className="text-sm text-muted-foreground">35% bis Blütephase</span>
                    </div>
                    <Progress value={35} className="h-2" />
                  </div>

                  {/* Environmental Stats */}
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-3 bg-muted/50 rounded-lg">
                      <Thermometer className="w-5 h-5 text-primary mx-auto mb-1" />
                      <p className="text-sm font-medium text-foreground">24°C</p>
                      <p className="text-xs text-muted-foreground">Temperatur</p>
                    </div>
                    <div className="text-center p-3 bg-muted/50 rounded-lg">
                      <Droplets className="w-5 h-5 text-primary mx-auto mb-1" />
                      <p className="text-sm font-medium text-foreground">65%</p>
                      <p className="text-xs text-muted-foreground">Luftfeuchtigkeit</p>
                    </div>
                    <div className="text-center p-3 bg-muted/50 rounded-lg">
                      <Sun className="w-5 h-5 text-primary mx-auto mb-1" />
                      <p className="text-sm font-medium text-foreground">18h</p>
                      <p className="text-xs text-muted-foreground">Lichtzykl.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* AI Recommendations */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">KI-Empfehlungen</CardTitle>
                    <Link href="/analysis">
                      <Button variant="ghost" size="sm">
                        <BarChart3 className="w-4 h-4 mr-1" />
                        Details
                      </Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-3 p-3 bg-orange-100 rounded-lg border border-orange-200">
                    <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-foreground">Nährstoffmangel erkannt</p>
                      <p className="text-xs text-muted-foreground">Stickstoff-Düngung erhöhen</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 bg-accent/10 rounded-lg border border-accent/20">
                    <Droplets className="w-5 h-5 text-accent mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-foreground">Bewässerung anpassen</p>
                      <p className="text-xs text-muted-foreground">Intervall auf 2 Tage reduzieren</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 bg-primary/10 rounded-lg border border-primary/20">
                    <Sun className="w-5 h-5 text-primary mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-foreground">Lichtversorgung optimal</p>
                      <p className="text-xs text-muted-foreground">Aktuelle Einstellung beibehalten</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Schnellaktionen</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Link href="/upload">
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <Camera className="w-4 h-4 mr-2" />
                      Foto hochladen
                    </Button>
                  </Link>
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Plus className="w-4 h-4 mr-2" />
                    Neue Pflanze hinzufügen
                  </Button>
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Calendar className="w-4 h-4 mr-2" />
                    Wachstumstagebuch
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
