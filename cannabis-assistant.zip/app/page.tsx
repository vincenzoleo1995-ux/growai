"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Leaf, Camera, Brain, Users, CheckCircle, ArrowRight, Sparkles } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  const [isAnimating, setIsAnimating] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-green-50/30 via-background to-green-50/20" />
        {/* Floating cannabis leaves animation */}
        <div className="absolute top-10 left-10 animate-bounce delay-1000">
          <Leaf className="w-8 h-8 text-green-200 rotate-12" />
        </div>
        <div className="absolute top-32 right-20 animate-pulse delay-2000">
          <Leaf className="w-6 h-6 text-green-300 -rotate-45" />
        </div>
        <div className="absolute bottom-20 left-1/4 animate-bounce delay-3000">
          <Leaf className="w-10 h-10 text-green-100 rotate-45" />
        </div>
        <div className="absolute bottom-40 right-1/3 animate-pulse delay-500">
          <Leaf className="w-7 h-7 text-green-200 -rotate-12" />
        </div>
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-border bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">GrowAI</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="#features">
              <a className="text-muted-foreground hover:text-foreground transition-colors">Funktionen</a>
            </Link>
            <Link href="#pricing">
              <a className="text-muted-foreground hover:text-foreground transition-colors">Preise</a>
            </Link>
            <Link href="#about">
              <a className="text-muted-foreground hover:text-foreground transition-colors">Über uns</a>
            </Link>
          </nav>
          <div className="flex items-center gap-3">
            <Link href="/auth">
              <Button variant="ghost" size="sm">
                Anmelden
              </Button>
            </Link>
            <Link href="/auth">
              <Button size="sm" className="bg-primary hover:bg-primary/90">
                Kostenlos testen
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative z-10 py-20 px-4">
        <div className="container mx-auto text-center max-w-4xl">
          <Badge className="mb-6 bg-accent/10 text-accent-foreground border-accent/20">
            <Sparkles className="w-4 h-4 mr-1" />
            KI-gestützte Cannabis-Zucht
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 text-balance">
            Von der Saat zur <span className="text-primary">perfekten Pflanze</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 text-pretty max-w-2xl mx-auto">
            Unser KI-Assistent begleitet Sie Schritt für Schritt durch den gesamten Anbauprozess. Personalisierte
            Empfehlungen basierend auf wöchentlichen Fotos Ihrer Pflanzen.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth">
              <Button
                size="lg"
                className="bg-primary hover:bg-primary/90 text-primary-foreground px-8"
                onClick={() => setIsAnimating(true)}
              >
                1 Stunde kostenlos testen
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Button variant="outline" size="lg" className="px-8 bg-transparent">
              Demo ansehen
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="relative z-10 py-20 px-4 bg-card/30">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Wie GrowAI funktioniert</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Einfacher 4-Schritte-Prozess für optimale Ergebnisse
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center border-border/50 hover:border-primary/20 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-lg">1. Registrierung</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Schnelle Anmeldung und Zugang zu allen Funktionen</CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center border-border/50 hover:border-primary/20 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Leaf className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-lg">2. Sorte wählen</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Cannabis-Sorte auswählen und Pflanzendaten eingeben</CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center border-border/50 hover:border-primary/20 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Camera className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-lg">3. Foto hochladen</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Wöchentliche Fotos für KI-Analyse und Überwachung</CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center border-border/50 hover:border-primary/20 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Brain className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-lg">4. KI-Empfehlungen</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Personalisierte Tipps für Bewässerung, Düngung und Pflege</CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="relative z-10 py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Einfache Preisgestaltung</h2>
            <p className="text-lg text-muted-foreground">Starten Sie kostenlos und upgraden Sie jederzeit</p>
          </div>

          <div className="max-w-md mx-auto">
            <Card className="border-primary/20 shadow-lg">
              <CardHeader className="text-center">
                <Badge className="w-fit mx-auto mb-4 bg-accent text-accent-foreground">Beliebt</Badge>
                <CardTitle className="text-2xl">Pro Plan</CardTitle>
                <CardDescription className="text-lg">Vollständiger Zugang zu allen Funktionen</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-primary">€9,99</span>
                  <span className="text-muted-foreground">/Monat</span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-primary" />
                    <span>1 Stunde kostenlose Testversion</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-primary" />
                    <span>Unbegrenzte Pflanzen</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-primary" />
                    <span>Wöchentliche KI-Analyse</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-primary" />
                    <span>Personalisierte Empfehlungen</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-primary" />
                    <span>24/7 Support</span>
                  </div>
                </div>
                <Link href="/auth">
                  <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mt-6">
                    Jetzt kostenlos testen
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border bg-card/30 py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Leaf className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="text-xl font-bold text-foreground">GrowAI</span>
              </div>
              <p className="text-muted-foreground text-sm">Professioneller KI-Assistent für den Cannabis-Anbau</p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-3">Produkt</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Funktionen
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Preise
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Demo
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-3">Unternehmen</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Über uns
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Kontakt
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Blog
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-3">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Datenschutz
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    AGB
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Impressum
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
            © 2024 GrowAI. Alle Rechte vorbehalten.
          </div>
        </div>
      </footer>
    </div>
  )
}
