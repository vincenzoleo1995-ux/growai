"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Leaf,
  ArrowLeft,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  Droplets,
  Sun,
  Calendar,
  Camera,
  Download,
  Share,
} from "lucide-react"
import Link from "next/link"

const analysisData = {
  overallHealth: 87,
  previousHealth: 92,
  recommendations: [
    {
      type: "critical",
      icon: AlertTriangle,
      title: "Nährstoffmangel erkannt",
      description: "Leichte Gelbfärbung der unteren Blätter deutet auf Stickstoffmangel hin",
      action: "Erhöhen Sie die Stickstoff-Düngung um 20%",
      priority: "Hoch",
    },
    {
      type: "warning",
      icon: Droplets,
      title: "Bewässerung anpassen",
      description: "Erde erscheint zu trocken, Blätter zeigen leichte Welke-Anzeichen",
      action: "Bewässerungsintervall von 3 auf 2 Tage reduzieren",
      priority: "Mittel",
    },
    {
      type: "success",
      icon: Sun,
      title: "Lichtversorgung optimal",
      description: "Pflanzen zeigen gesundes Wachstum und gute Lichtaufnahme",
      action: "Aktuelle Beleuchtung beibehalten",
      priority: "Info",
    },
  ],
  metrics: {
    leafHealth: 85,
    stemStrength: 92,
    colorConsistency: 78,
    growthRate: 88,
  },
  schedule: [
    { day: "Heute", task: "Stickstoff-Dünger hinzufügen", type: "fertilizer" },
    { day: "Morgen", task: "Bewässerung", type: "water" },
    { day: "In 2 Tagen", task: "Blätter auf Verbesserung prüfen", type: "check" },
    { day: "In 5 Tagen", task: "Nächste Foto-Analyse", type: "photo" },
  ],
}

export default function AnalysisPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const healthChange = analysisData.overallHealth - analysisData.previousHealth

  return (
    <div className="min-h-screen bg-background">
      {/* Background Animation */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-green-50/30 via-background to-green-50/20" />
        <div className="absolute top-10 left-10 animate-bounce delay-1000">
          <Leaf className="w-8 h-8 text-green-200 rotate-12" />
        </div>
        <div className="absolute bottom-20 right-20 animate-pulse delay-2000">
          <Leaf className="w-6 h-6 text-green-300 -rotate-45" />
        </div>
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-border bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">GrowAI</span>
          </Link>
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Bericht herunterladen
            </Button>
            <Button variant="outline" size="sm">
              <Share className="w-4 h-4 mr-2" />
              Teilen
            </Button>
          </div>
        </div>
      </header>

      <div className="relative z-10 py-8 px-4">
        <div className="container mx-auto max-w-6xl">
          {/* Header */}
          <div className="mb-8">
            <Link
              href="/dashboard"
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-4"
            >
              <ArrowLeft className="w-4 h-4" />
              Zurück zum Dashboard
            </Link>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">KI-Analyse Ergebnisse</h1>
                <p className="text-muted-foreground">
                  White Widow #1 • Analysiert am {new Date().toLocaleDateString("de-DE")}
                </p>
              </div>
              <Badge className="bg-primary/10 text-primary border-primary/20 text-lg px-4 py-2">
                Gesundheitsscore: {analysisData.overallHealth}%
              </Badge>
            </div>
          </div>

          {/* Health Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Gesamtgesundheit</p>
                    <p className="text-2xl font-bold text-foreground">{analysisData.overallHealth}%</p>
                    <div className="flex items-center gap-1 mt-1">
                      {healthChange < 0 ? (
                        <TrendingDown className="w-4 h-4 text-destructive" />
                      ) : (
                        <TrendingUp className="w-4 h-4 text-primary" />
                      )}
                      <span className={`text-sm ${healthChange < 0 ? "text-destructive" : "text-primary"}`}>
                        {healthChange > 0 ? "+" : ""}
                        {healthChange}%
                      </span>
                    </div>
                  </div>
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Leaf className="w-5 h-5 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Blattgesundheit</p>
                    <p className="text-2xl font-bold text-foreground">{analysisData.metrics.leafHealth}%</p>
                  </div>
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Leaf className="w-5 h-5 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Stammstärke</p>
                    <p className="text-2xl font-bold text-foreground">{analysisData.metrics.stemStrength}%</p>
                  </div>
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Wachstumsrate</p>
                    <p className="text-2xl font-bold text-foreground">{analysisData.metrics.growthRate}%</p>
                  </div>
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Analysis */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">Übersicht</TabsTrigger>
              <TabsTrigger value="recommendations">Empfehlungen</TabsTrigger>
              <TabsTrigger value="schedule">Zeitplan</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-6">
              <div className="grid lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Detaillierte Metriken</CardTitle>
                    <CardDescription>Bewertung verschiedener Gesundheitsaspekte</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Blattgesundheit</span>
                        <span className="text-sm text-muted-foreground">{analysisData.metrics.leafHealth}%</span>
                      </div>
                      <Progress value={analysisData.metrics.leafHealth} className="h-2" />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Stammstärke</span>
                        <span className="text-sm text-muted-foreground">{analysisData.metrics.stemStrength}%</span>
                      </div>
                      <Progress value={analysisData.metrics.stemStrength} className="h-2" />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Farbkonsistenz</span>
                        <span className="text-sm text-muted-foreground">{analysisData.metrics.colorConsistency}%</span>
                      </div>
                      <Progress value={analysisData.metrics.colorConsistency} className="h-2" />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Wachstumsrate</span>
                        <span className="text-sm text-muted-foreground">{analysisData.metrics.growthRate}%</span>
                      </div>
                      <Progress value={analysisData.metrics.growthRate} className="h-2" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Analysierte Fotos</CardTitle>
                    <CardDescription>Hochgeladene Bilder mit KI-Markierungen</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      {[1, 2, 3, 4].map((i) => (
                        <div
                          key={i}
                          className="aspect-square bg-muted rounded-lg flex items-center justify-center border"
                        >
                          <div className="text-center">
                            <Camera className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                            <p className="text-xs text-muted-foreground">Foto {i}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="recommendations" className="mt-6">
              <div className="space-y-4">
                {analysisData.recommendations.map((rec, index) => {
                  const Icon = rec.icon
                  const bgColor =
                    rec.type === "critical"
                      ? "bg-destructive/10 border-destructive/20"
                      : rec.type === "warning"
                        ? "bg-orange-100 border-orange-200"
                        : "bg-primary/10 border-primary/20"
                  const iconColor =
                    rec.type === "critical"
                      ? "text-destructive"
                      : rec.type === "warning"
                        ? "text-orange-600"
                        : "text-primary"

                  return (
                    <Card key={index} className={`${bgColor}`}>
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${bgColor}`}>
                            <Icon className={`w-5 h-5 ${iconColor}`} />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="font-semibold text-foreground">{rec.title}</h3>
                              <Badge variant="outline" className="text-xs">
                                {rec.priority}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-3">{rec.description}</p>
                            <div className="bg-background/50 rounded-lg p-3">
                              <p className="text-sm font-medium text-foreground">Empfohlene Maßnahme:</p>
                              <p className="text-sm text-muted-foreground">{rec.action}</p>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </TabsContent>

            <TabsContent value="schedule" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Empfohlener Pflegeplan</CardTitle>
                  <CardDescription>Basierend auf der KI-Analyse generierter Zeitplan</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analysisData.schedule.map((item, index) => {
                      const getIcon = (type: string) => {
                        switch (type) {
                          case "fertilizer":
                            return <Leaf className="w-5 h-5 text-primary" />
                          case "water":
                            return <Droplets className="w-5 h-5 text-blue-500" />
                          case "check":
                            return <CheckCircle className="w-5 h-5 text-green-500" />
                          case "photo":
                            return <Camera className="w-5 h-5 text-purple-500" />
                          default:
                            return <Calendar className="w-5 h-5 text-muted-foreground" />
                        }
                      }

                      return (
                        <div key={index} className="flex items-center gap-4 p-4 border border-border rounded-lg">
                          <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                            {getIcon(item.type)}
                          </div>
                          <div className="flex-1">
                            <p className="font-medium text-foreground">{item.task}</p>
                            <p className="text-sm text-muted-foreground">{item.day}</p>
                          </div>
                          <Button variant="outline" size="sm">
                            Erledigt
                          </Button>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Action Buttons */}
          <div className="flex gap-4 mt-8">
            <Button className="bg-primary hover:bg-primary/90">
              <Camera className="w-4 h-4 mr-2" />
              Neues Foto hochladen
            </Button>
            <Button variant="outline">Empfehlungen als erledigt markieren</Button>
          </div>
        </div>
      </div>
    </div>
  )
}
