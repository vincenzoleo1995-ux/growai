"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Leaf, Camera, Upload, ArrowLeft, CheckCircle, AlertCircle, Clock, ImageIcon, X } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function UploadPage() {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisProgress, setAnalysisProgress] = useState(0)
  const [plantSelection, setPlantSelection] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    setSelectedFiles((prev) => [...prev, ...files].slice(0, 5)) // Max 5 photos
  }

  const removeFile = (index: number) => {
    setSelectedFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const handleAnalysis = async () => {
    if (selectedFiles.length === 0 || !plantSelection) return

    setIsAnalyzing(true)
    setAnalysisProgress(0)

    // Simulate AI analysis progress
    const progressInterval = setInterval(() => {
      setAnalysisProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval)
          setTimeout(() => {
            window.location.href = "/analysis"
          }, 1000)
          return 100
        }
        return prev + Math.random() * 15
      })
    }, 300)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Background Animation */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-green-50/30 via-background to-green-50/20" />
        <div className="absolute top-10 left-10 animate-bounce delay-1000">
          <Leaf className="w-8 h-8 text-green-200 rotate-12" />
        </div>
        <div className="absolute bottom-20 right-20 animate-pulse delay-2000">
          <Leaf className="w-6 h-6 text-green-300 -rotate-45" />
        </div>
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-border bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">GrowAI</span>
          </Link>
          <Badge variant="outline" className="bg-accent/10 text-accent border-accent/20">
            <Clock className="w-3 h-3 mr-1" />
            42 Min. Testversion
          </Badge>
        </div>
      </header>

      <div className="relative z-10 py-8 px-4">
        <div className="container mx-auto max-w-4xl">
          {/* Header */}
          <div className="mb-8">
            <Link
              href="/dashboard"
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-4"
            >
              <ArrowLeft className="w-4 h-4" />
              Zurück zum Dashboard
            </Link>
            <h1 className="text-3xl font-bold text-foreground mb-2">Wöchentliche Foto-Analyse</h1>
            <p className="text-muted-foreground">
              Laden Sie aktuelle Fotos Ihrer Pflanzen hoch und erhalten Sie personalisierte KI-Empfehlungen
            </p>
          </div>

          {!isAnalyzing ? (
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Upload Section */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Camera className="w-5 h-5 text-primary" />
                      Fotos hochladen
                    </CardTitle>
                    <CardDescription>
                      Laden Sie bis zu 5 Fotos Ihrer Pflanzen aus verschiedenen Winkeln hoch
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Plant Selection */}
                    <div className="space-y-2">
                      <Label htmlFor="plant">Pflanze auswählen</Label>
                      <Select value={plantSelection} onValueChange={setPlantSelection}>
                        <SelectTrigger>
                          <SelectValue placeholder="Wählen Sie eine Pflanze..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="white-widow-1">White Widow #1 (Tag 21)</SelectItem>
                          <SelectItem value="white-widow-2">White Widow #2 (Tag 21)</SelectItem>
                          <SelectItem value="white-widow-3">White Widow #3 (Tag 19)</SelectItem>
                          <SelectItem value="white-widow-4">White Widow #4 (Tag 21)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* File Upload Area */}
                    <div
                      className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary/50 transition-colors cursor-pointer"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-foreground mb-2">Fotos hier ablegen</h3>
                      <p className="text-muted-foreground mb-4">oder klicken Sie hier, um Dateien auszuwählen</p>
                      <p className="text-sm text-muted-foreground">JPG, PNG bis zu 10MB • Maximal 5 Fotos</p>
                      <input
                        ref={fileInputRef}
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={handleFileSelect}
                        className="hidden"
                      />
                    </div>

                    {/* Selected Files */}
                    {selectedFiles.length > 0 && (
                      <div className="space-y-3">
                        <h4 className="font-medium text-foreground">Ausgewählte Fotos ({selectedFiles.length}/5)</h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                          {selectedFiles.map((file, index) => (
                            <div key={index} className="relative group">
                              <div className="aspect-square bg-muted rounded-lg overflow-hidden border">
                                <Image
                                  src={URL.createObjectURL(file) || "/placeholder.svg"}
                                  alt={`Upload ${index + 1}`}
                                  width={200}
                                  height={200}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <Button
                                variant="destructive"
                                size="sm"
                                className="absolute -top-2 -right-2 w-6 h-6 rounded-full p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                                onClick={() => removeFile(index)}
                              >
                                <X className="w-3 h-3" />
                              </Button>
                              <p className="text-xs text-muted-foreground mt-1 truncate">{file.name}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Notes */}
                    <div className="space-y-2">
                      <Label htmlFor="notes">Zusätzliche Notizen (optional)</Label>
                      <Textarea
                        id="notes"
                        placeholder="Besondere Beobachtungen, Veränderungen seit dem letzten Foto, etc..."
                        rows={3}
                      />
                    </div>

                    <Button
                      onClick={handleAnalysis}
                      disabled={selectedFiles.length === 0 || !plantSelection}
                      className="w-full bg-primary hover:bg-primary/90"
                      size="lg"
                    >
                      <Camera className="w-5 h-5 mr-2" />
                      KI-Analyse starten
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Tips Sidebar */}
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Foto-Tipps</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-primary mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-foreground">Gute Beleuchtung</p>
                        <p className="text-xs text-muted-foreground">Natürliches Licht oder helle LED-Beleuchtung</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-primary mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-foreground">Verschiedene Winkel</p>
                        <p className="text-xs text-muted-foreground">Gesamtansicht, Blätter, Stamm</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-primary mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-foreground">Scharfe Bilder</p>
                        <p className="text-xs text-muted-foreground">Vermeiden Sie unscharfe oder verwackelte Fotos</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-orange-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-foreground">Probleme zeigen</p>
                        <p className="text-xs text-muted-foreground">Fotografieren Sie auch Problemstellen</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Letzte Analyse</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-4">
                      <ImageIcon className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">Vor 4 Tagen</p>
                      <p className="text-xs text-muted-foreground">Gesundheitsscore: 92%</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          ) : (
            /* Analysis Progress */
            <Card className="max-w-2xl mx-auto">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Camera className="w-8 h-8 text-primary animate-pulse" />
                </div>
                <CardTitle>KI analysiert Ihre Pflanzen</CardTitle>
                <CardDescription>
                  Unsere KI untersucht Ihre Fotos und erstellt personalisierte Empfehlungen
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-foreground">Analyse-Fortschritt</span>
                    <span className="text-sm text-muted-foreground">{Math.round(analysisProgress)}%</span>
                  </div>
                  <Progress value={analysisProgress} className="h-3" />
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${analysisProgress > 20 ? "bg-primary" : "bg-muted"}`} />
                    <span className="text-sm text-muted-foreground">Fotos werden verarbeitet...</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${analysisProgress > 50 ? "bg-primary" : "bg-muted"}`} />
                    <span className="text-sm text-muted-foreground">Pflanzengesundheit wird bewertet...</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${analysisProgress > 80 ? "bg-primary" : "bg-muted"}`} />
                    <span className="text-sm text-muted-foreground">Empfehlungen werden generiert...</span>
                  </div>
                </div>

                {analysisProgress >= 100 && (
                  <div className="text-center pt-4">
                    <CheckCircle className="w-12 h-12 text-primary mx-auto mb-2" />
                    <p className="text-sm font-medium text-foreground">Analyse abgeschlossen!</p>
                    <p className="text-xs text-muted-foreground">Sie werden weitergeleitet...</p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
