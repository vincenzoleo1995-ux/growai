"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Leaf, ArrowLeft, CreditCard, Download, CheckCircle, AlertCircle, Crown, Settings } from "lucide-react"
import Link from "next/link"

const invoices = [
  { id: "INV-001", date: "2024-01-15", amount: 11.88, status: "paid" },
  { id: "INV-002", date: "2024-02-15", amount: 11.88, status: "paid" },
  { id: "INV-003", date: "2024-03-15", amount: 11.88, status: "pending" },
]

export default function BillingPage() {
  const [showSuccess, setShowSuccess] = useState(false)

  useEffect(() => {
    // Check if coming from successful payment
    const urlParams = new URLSearchParams(window.location.search)
    if (urlParams.get("success") === "true") {
      setShowSuccess(true)
      // Remove the success parameter from URL
      window.history.replaceState({}, "", "/billing")
    }
  }, [])

  return (
    <div className="min-h-screen bg-background">
      {/* Background Animation */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-green-50/30 via-background to-green-50/20" />
        <div className="absolute top-10 left-10 animate-bounce delay-1000">
          <Leaf className="w-8 h-8 text-green-200 rotate-12" />
        </div>
        <div className="absolute bottom-20 right-20 animate-pulse delay-2000">
          <Leaf className="w-6 h-6 text-green-300 -rotate-45" />
        </div>
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-border bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">GrowAI</span>
          </Link>
          <Badge className="bg-primary/10 text-primary border-primary/20">
            <Crown className="w-3 h-3 mr-1" />
            Pro Mitglied
          </Badge>
        </div>
      </header>

      <div className="relative z-10 py-8 px-4">
        <div className="container mx-auto max-w-4xl">
          {/* Success Message */}
          {showSuccess && (
            <Card className="mb-8 border-primary/20 bg-primary/5">
              <CardContent className="p-6">
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-8 h-8 text-primary" />
                  <div>
                    <h3 className="font-semibold text-foreground">Willkommen bei GrowAI Pro!</h3>
                    <p className="text-sm text-muted-foreground">
                      Ihre Zahlung war erfolgreich. Sie haben jetzt Zugang zu allen Premium-Funktionen.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Header */}
          <div className="mb-8">
            <Link
              href="/dashboard"
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-4"
            >
              <ArrowLeft className="w-4 h-4" />
              Zurück zum Dashboard
            </Link>
            <h1 className="text-3xl font-bold text-foreground mb-2">Abrechnung & Abonnement</h1>
            <p className="text-muted-foreground">Verwalten Sie Ihr Abonnement und Rechnungen</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Current Plan */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="w-5 h-5 text-primary" />
                    Aktueller Plan
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold text-foreground">GrowAI Pro</h3>
                      <p className="text-sm text-muted-foreground">Monatliches Abonnement</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-primary">€9,99</p>
                      <p className="text-sm text-muted-foreground">pro Monat</p>
                    </div>
                  </div>

                  <Separator />

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Nächste Abrechnung</p>
                      <p className="font-medium">15. April 2024</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Status</p>
                      <Badge className="bg-primary/10 text-primary border-primary/20">Aktiv</Badge>
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4">
                    <Button variant="outline" className="flex-1 bg-transparent">
                      <Settings className="w-4 h-4 mr-2" />
                      Plan ändern
                    </Button>
                    <Button variant="outline" className="flex-1 bg-transparent">
                      Kündigen
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Method */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-primary" />
                    Zahlungsmethode
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                        <CreditCard className="w-5 h-5 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">•••• •••• •••• 1234</p>
                        <p className="text-sm text-muted-foreground">Läuft ab 12/26</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      Bearbeiten
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Invoices */}
              <Card>
                <CardHeader>
                  <CardTitle>Rechnungshistorie</CardTitle>
                  <CardDescription>Ihre letzten Rechnungen und Zahlungen</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {invoices.map((invoice) => (
                      <div
                        key={invoice.id}
                        className="flex items-center justify-between p-3 border border-border rounded-lg"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-muted rounded flex items-center justify-center">
                            {invoice.status === "paid" ? (
                              <CheckCircle className="w-4 h-4 text-primary" />
                            ) : (
                              <AlertCircle className="w-4 h-4 text-orange-500" />
                            )}
                          </div>
                          <div>
                            <p className="font-medium text-foreground">{invoice.id}</p>
                            <p className="text-sm text-muted-foreground">{invoice.date}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <p className="font-medium text-foreground">€{invoice.amount.toFixed(2)}</p>
                            <Badge
                              variant={invoice.status === "paid" ? "default" : "secondary"}
                              className={
                                invoice.status === "paid" ? "bg-primary/10 text-primary border-primary/20" : ""
                              }
                            >
                              {invoice.status === "paid" ? "Bezahlt" : "Ausstehend"}
                            </Badge>
                          </div>
                          <Button variant="ghost" size="sm">
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Usage Stats */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Nutzungsstatistiken</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>KI-Analysen</span>
                      <span>12 / ∞</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-primary h-2 rounded-full w-full"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Aktive Pflanzen</span>
                      <span>4 / ∞</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-primary h-2 rounded-full w-full"></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Support-Anfragen</span>
                      <span>2 / ∞</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-primary h-2 rounded-full w-full"></div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Support */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Benötigen Sie Hilfe?</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    Support kontaktieren
                  </Button>
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    FAQ ansehen
                  </Button>
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    Feedback geben
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
