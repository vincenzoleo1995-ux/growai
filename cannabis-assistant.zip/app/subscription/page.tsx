"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Leaf, ArrowLeft, Clock, Crown, Check } from "lucide-react"
import Link from "next/link"

const basicFeatures = [
  "1 Pflanze verwalten",
  "Wöchentliche KI-Analyse",
  "Grundlegende Empfehlungen",
  "Mobile App Zugang",
  "E-Mail Support",
]

const proFeatures = [
  "Bis zu 3 Pflanzen verwalten",
  "Unbegrenzte KI-Analysen",
  "Erweiterte Empfehlungen",
  "Detaillierte Wachstumstrends",
  "Prioritäts-Support",
  "Erweiterte Berichte",
]

export default function SubscriptionPage() {
  const [isYearly, setIsYearly] = useState(false)
  const [trialTimeLeft] = useState(42)

  return (
    <div className="min-h-screen bg-background">
      {/* Background Animation */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-green-50/30 via-background to-green-50/20" />
        <div className="absolute top-10 left-10 animate-bounce delay-1000">
          <Leaf className="w-8 h-8 text-green-200 rotate-12" />
        </div>
        <div className="absolute bottom-20 right-20 animate-pulse delay-2000">
          <Leaf className="w-6 h-6 text-green-300 -rotate-45" />
        </div>
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-border bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">GrowAI</span>
          </Link>
          <Badge variant="outline" className="bg-accent/10 text-accent border-accent/20">
            <Clock className="w-3 h-3 mr-1" />
            {trialTimeLeft} Min. Testversion
          </Badge>
        </div>
      </header>

      <div className="relative z-10 py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          {/* Header */}
          <div className="text-center mb-12">
            <Link
              href="/dashboard"
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6"
            >
              <ArrowLeft className="w-4 h-4" />
              Zurück zum Dashboard
            </Link>
            <h1 className="text-4xl font-bold text-foreground mb-4">Wählen Sie Ihren Plan</h1>
            <p className="text-xl text-muted-foreground mb-6">
              Schalten Sie das volle Potenzial Ihres Cannabis-Anbaus frei
            </p>

            {/* Trial Warning */}
            <Card className="max-w-md mx-auto mb-8 border-accent/20 bg-accent/5">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-accent" />
                  <div className="text-left">
                    <p className="font-medium text-foreground">Testversion läuft ab</p>
                    <p className="text-sm text-muted-foreground">Noch {trialTimeLeft} Minuten verbleibend</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Pricing Toggle */}
          <div className="flex items-center justify-center mb-8">
            <div className="bg-muted p-1 rounded-lg">
              <Button
                variant={!isYearly ? "default" : "ghost"}
                size="sm"
                onClick={() => setIsYearly(false)}
                className="px-6"
              >
                Monatlich
              </Button>
              <Button
                variant={isYearly ? "default" : "ghost"}
                size="sm"
                onClick={() => setIsYearly(true)}
                className="px-6"
              >
                Jährlich
                <Badge className="ml-2 bg-accent text-accent-foreground">-20%</Badge>
              </Button>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12 max-w-4xl mx-auto">
            {/* 1 Plant Plan */}
            <Card className="border-border shadow-lg">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Leaf className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-2xl">1 Pflanze Plan</CardTitle>
                <CardDescription className="text-lg">Perfekt für Einsteiger</CardDescription>
                <div className="mt-6">
                  {isYearly ? (
                    <div>
                      <span className="text-4xl font-bold text-primary">€95,90</span>
                      <span className="text-muted-foreground">/Jahr</span>
                      <p className="text-sm text-muted-foreground mt-1">Entspricht €7,99/Monat • 20% Ersparnis</p>
                    </div>
                  ) : (
                    <div>
                      <span className="text-4xl font-bold text-primary">€9,99</span>
                      <span className="text-muted-foreground">/Monat</span>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  {basicFeatures.map((feature, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <Check className="w-5 h-5 text-primary" />
                      <span className="text-foreground">{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-4 space-y-3">
                  <Link href="/checkout?plan=basic">
                    <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground" size="lg">
                      Plan wählen
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* 3 Plant Plan */}
            <Card className="border-primary/20 shadow-lg relative">
              <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-primary text-primary-foreground">
                Beliebt
              </Badge>
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Crown className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-2xl">3 Pflanzen Plan</CardTitle>
                <CardDescription className="text-lg">Für erfahrene Züchter</CardDescription>
                <div className="mt-6">
                  {isYearly ? (
                    <div>
                      <span className="text-4xl font-bold text-primary">€191,80</span>
                      <span className="text-muted-foreground">/Jahr</span>
                      <p className="text-sm text-muted-foreground mt-1">Entspricht €15,98/Monat • 20% Ersparnis</p>
                    </div>
                  ) : (
                    <div>
                      <span className="text-4xl font-bold text-primary">€19,99</span>
                      <span className="text-muted-foreground">/Monat</span>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  {proFeatures.map((feature, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <Check className="w-5 h-5 text-primary" />
                      <span className="text-foreground">{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-4 space-y-3">
                  <Link href="/checkout?plan=pro">
                    <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground" size="lg">
                      Plan wählen
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* FAQ Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-center">Häufig gestellte Fragen</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h4 className="font-medium text-foreground mb-2">Kann ich jederzeit kündigen?</h4>
                <p className="text-sm text-muted-foreground">
                  Ja, Sie können Ihr Abonnement jederzeit ohne Kündigungsfristen beenden. Sie haben bis zum Ende Ihres
                  Abrechnungszeitraums Zugang zu allen Premium-Funktionen.
                </p>
              </div>
              <div>
                <h4 className="font-medium text-foreground mb-2">Was passiert nach der kostenlosen Testversion?</h4>
                <p className="text-sm text-muted-foreground">
                  Nach Ablauf der 1-stündigen Testversion haben Sie weiterhin Zugang zu grundlegenden Funktionen, aber
                  Premium-Features wie unbegrenzte KI-Analysen erfordern ein Abonnement.
                </p>
              </div>
              <div>
                <h4 className="font-medium text-foreground mb-2">Kann ich zwischen den Plänen wechseln?</h4>
                <p className="text-sm text-muted-foreground">
                  Ja, Sie können jederzeit zwischen dem 1 Pflanze Plan und dem 3 Pflanzen Plan wechseln. Änderungen
                  werden am nächsten Abrechnungszyklus wirksam.
                </p>
              </div>
              <div>
                <h4 className="font-medium text-foreground mb-2">Gibt es eine Geld-zurück-Garantie?</h4>
                <p className="text-sm text-muted-foreground">
                  Ja, wir bieten eine 30-tägige Geld-zurück-Garantie. Wenn Sie nicht zufrieden sind, erstatten wir Ihnen
                  den vollen Betrag.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
